function thanhToan() {
    // Xử lý thanh toán
    alert("Xử lý thanh toán...");
}

function quayLai() {
    // Quay lại trang trước đó
    window.history.back();
}
    // JavaScript
    document.getElementById("user-icon").addEventListener("click", function() {
        document.getElementById("loginModal").style.display = "block";
    });

    document.getElementsByClassName("close")[0].addEventListener("click", function() {
        document.getElementById("loginModal").style.display = "none";
    });

    window.addEventListener("click", function(event) {
        if (event.target == document.getElementById("loginModal")) {
            document.getElementById("loginModal").style.display = "none";
        }
    });

    // Xử lý đăng nhập
    document.getElementById("loginForm").addEventListener("submit", function(event) {
        event.preventDefault(); // Ngăn chặn form gửi đi
        // Thực hiện kiểm tra đăng nhập ở đây
        alert("Đăng nhập thành công!"); // Đây chỉ là ví dụ, bạn cần thay đổi theo logic của bạn
        document.getElementById("loginModal").style.display = "none"; // Đóng modal sau khi đăng nhập thành công
    });